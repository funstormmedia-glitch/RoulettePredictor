# Roulette Predictor (European 0–36)

Android project with:
- Manual entry of previous roulette results
- Number, colour, and odd/even trend estimates
- Locally saved history, undo, and clear
- GitHub Actions workflow to build a debug APK

## Build APK from a phone using GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the outer folder itself).
3. Open **Actions** → **Build Roulette Predictor APK**.
4. Tap **Run workflow** and wait for the green check.
5. Open the completed run, scroll to **Artifacts**, and download `roulette-predictor-debug-apk`.
6. Extract the downloaded ZIP and install `app-debug.apk` on Android (allow installation from that source if prompted).

## Important limitation
Roulette outcomes are random and each spin is independent. The app reports descriptive, recency-weighted patterns from entered history; it cannot know or reliably predict the next result.
