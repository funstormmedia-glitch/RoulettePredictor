package com.example.roulettepredictor;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private EditText resultInput;
    private TextView output, historyView;
    private SharedPreferences prefs;
    private final int[] reds = {1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36};
    private final int[] wheel = {0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26};
    private final ArrayList<Integer> history = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("roulette", MODE_PRIVATE);
        String saved = prefs.getString("history", "");
        if (!saved.isEmpty()) for (String s : saved.split(",")) try { history.add(Integer.parseInt(s)); } catch(Exception ignored) {}
        buildUi();
        refreshHistory();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 28, 24, 24); page.setBackgroundColor(Color.rgb(18, 25, 35));
        scroll.addView(page);

        TextView title = label("ROULETTE PREDICTOR", 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER); page.addView(title);
        TextView sub = label("European Roulette • 0–36", 14, Color.LTGRAY, false);
        sub.setGravity(Gravity.CENTER); page.addView(sub);
        page.addView(space(20));

        page.addView(label("Enter latest results (oldest to newest)", 16, Color.WHITE, true));
        resultInput = new EditText(this);
        resultInput.setSingleLine(false); resultInput.setMinLines(2); resultInput.setTextColor(Color.WHITE);
        resultInput.setHintTextColor(Color.LTGRAY); resultInput.setHint("Example: 12, 7, 0, 24, 18");
        resultInput.setTextSize(16); resultInput.setPadding(14,12,14,12);
        resultInput.setBackgroundColor(Color.rgb(40,50,65)); page.addView(resultInput);
        page.addView(space(10));

        Button analyze = button("ANALYZE & PREDICT");
        analyze.setOnClickListener(v -> analyze()); page.addView(analyze);
        Button add = button("ADD LATEST SPIN");
        add.setOnClickListener(v -> addLatest()); page.addView(add);
        Button undo = button("UNDO LAST RESULT");
        undo.setOnClickListener(v -> { if (!history.isEmpty()) { history.remove(history.size()-1); save(); refreshHistory(); } });
        page.addView(undo);
        Button clear = button("CLEAR HISTORY");
        clear.setOnClickListener(v -> { history.clear(); save(); refreshHistory(); output.setText("History cleared. Add results to analyze."); });
        page.addView(clear);

        page.addView(space(18));
        output = label("Your prediction will appear here.", 17, Color.WHITE, false);
        output.setPadding(16,18,16,18); output.setBackgroundColor(Color.rgb(35,48,62)); page.addView(output);
        page.addView(space(18));
        page.addView(label("RECENT SPIN HISTORY", 16, Color.WHITE, true));
        historyView = label("", 14, Color.LTGRAY, false); page.addView(historyView);
        page.addView(space(16));
        TextView disclaimer = label("Important: Roulette spins are independent and random. Past results cannot reliably predict the next spin. These are statistical guesses only—not guaranteed outcomes. Please gamble responsibly.", 12, Color.rgb(255,205,120), false);
        page.addView(disclaimer);
        setContentView(scroll);
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(0,6,0,6); return t;
    }
    private View space(int h) { TextView v = new TextView(this); v.setHeight(h); return v; }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(34,112,140)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); b.setLayoutParams(p); return b;
    }
    private int colorOf(int n) { if(n==0) return 2; for(int r:reds) if(r==n) return 0; return 1; }
    private String colorName(int n) { return colorOf(n)==2 ? "GREEN" : colorOf(n)==0 ? "RED" : "BLACK"; }
    private int oddEven(int n) { return n==0 ? 2 : n%2; }

    private void parseInput() {
        String raw = resultInput.getText().toString().trim();
        if(raw.isEmpty()) return;
        String[] parts = raw.split("[,\\s]+");
        for(String p:parts) {
            if(p.isEmpty()) continue;
            int n = Integer.parseInt(p);
            if(n<0 || n>36) throw new IllegalArgumentException("Only numbers 0 to 36 are valid.");
            history.add(n);
        }
        save(); resultInput.setText(""); refreshHistory();
    }
    private void addLatest() {
        try {
            String s = resultInput.getText().toString().trim();
            if(s.isEmpty()) { Toast.makeText(this,"Enter a result first.",Toast.LENGTH_SHORT).show(); return; }
            String[] parts = s.split("[,\\s]+"); int n = Integer.parseInt(parts[parts.length-1]);
            if(n<0 || n>36) throw new IllegalArgumentException();
            history.add(n); save(); resultInput.setText(""); refreshHistory();
            Toast.makeText(this,"Added result: "+n,Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this,"Enter a valid number from 0 to 36.",Toast.LENGTH_LONG).show(); }
    }
    private void analyze() {
        try { parseInput(); } catch(Exception e) { Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); return; }
        if(history.isEmpty()) { output.setText("Please add at least one result first."); return; }

        double[] numberScore = new double[37];
        double[] colourScore = new double[3];
        double[] parityScore = new double[3];
        int n = history.size();
        // Recent observations receive more weight. This describes history; it does not imply predictive power.
        for(int i=0;i<n;i++) {
            int value = history.get(i);
            double weight = 1.0 + 2.0 * (i / (double)Math.max(1,n-1));
            numberScore[value] += weight;
            colourScore[colorOf(value)] += weight;
            parityScore[oddEven(value)] += weight;
        }
        int bestNumber = 0;
        for(int i=1;i<=36;i++) if(numberScore[i] > numberScore[bestNumber]) bestNumber=i;
        int bestColour=0; for(int i=1;i<3;i++) if(colourScore[i]>colourScore[bestColour]) bestColour=i;
        int bestParity=0; for(int i=1;i<3;i++) if(parityScore[i]>parityScore[bestParity]) bestParity=i;
        // Use the most frequent recent number as a heuristic, while explicitly reporting the small sample.
        String colour = bestColour==2 ? "GREEN" : bestColour==0 ? "RED" : "BLACK";
        String parity = bestParity==2 ? "ZERO (neither)" : bestParity==0 ? "EVEN" : "ODD";
        ArrayList<Integer> top = new ArrayList<>();
        for(int k=0;k<3;k++) {
            int best=-1; for(int j=0;j<=36;j++) if(!top.contains(j) && (best<0 || numberScore[j]>numberScore[best])) best=j;
            if(best>=0) top.add(best);
        }
        output.setText("STATISTICAL GUESS (not a reliable forecast)\n\n"
            +"Next number estimate: "+bestNumber+"\n"
            +"Number colour: "+colorName(bestNumber)+"\n"
            +"Colour trend estimate: "+colour+"\n"
            +"Odd / Even trend: "+parity+"\n\n"
            +"Most repeated weighted numbers: "+top+"\n"
            +"Results analyzed: "+n+"\n\n"
            +"A fair European wheel gives each number 1/37 chance per spin. Red/Black each have 18/37; odd/even each have 18/37. Previous spins do not change these odds.");
    }
    private void save() {
        StringBuilder b=new StringBuilder(); for(int i=0;i<history.size();i++){if(i>0)b.append(",");b.append(history.get(i));}
        prefs.edit().putString("history",b.toString()).apply();
    }
    private void refreshHistory() {
        int start=Math.max(0,history.size()-30);
        ArrayList<Integer> recent=new ArrayList<>(history.subList(start,history.size()));
        Collections.reverse(recent);
        historyView.setText(recent.isEmpty() ? "No results saved yet." : recent.toString()+"\n\nTotal saved: "+history.size());
    }
}
